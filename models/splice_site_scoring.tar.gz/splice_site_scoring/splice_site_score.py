## Takes a long sequence from stdin and finds all splice sites in it (both 5' donor sites (MaxEnt and Krainer), and 3' acceptor sites (MaxEnt only))
## Sequence can contain Ns, in which case we will score several different random settings and report the highest score

import sys
import numpy as np
import pandas as pd
import random
import itertools    
    

def fill_in_n(nts_with_n):
    return ("".join([nt if  (nt != 'N') else random.choice(['A','C','G','T']) for nt in nts_with_n]))
    

import maxentpy
matrix5 = maxentpy.load_matrix5()
def analyze_5ss(nts):
    assert(len(nts)==9)
    return maxentpy.score5(nts,matrix5)
    
matrix3 = maxentpy.load_matrix3()
def analyze_3ss(nts):
    assert(len(nts)==23)
    return maxentpy.score3(nts,matrix3)

# Analyze using Wong-Krainer data
krainer_data = pd.read_csv("krainer_data_psi.txt",sep="\t").set_index("ss").fillna(-1)
def analyze_5ss_krainer(nts): # analyze 9 nucleotides defining the 5'ss
    nts = nts.upper().replace("T","U")
    if (nts not in krainer_data.index):
        dummy_scores = krainer_data.loc["CAGGUAAGU"].copy()
        dummy_scores.brca2_9nt = -1
        dummy_scores.ikbkap_9nt = -1
        dummy_scores.smn1_9nt = -1
        return dummy_scores
        
    return krainer_data.loc[nts]
                
                
# Fill in Ns with random nucleotides and output the maximum score                
def analyze_with_n(nts, func):
    num_n = nts.count("N")
    num_attempts = (1 if num_n == 0 else 16)
    return np.amax([func(fill_in_n(nts)) for i in range(num_attempts)],axis=0)
        

                
###########################################


NUM_TO_PRINT = 20

while True:
    nts = input("Enter sequence (use 'stty -icanon' if len>4095; Ns reported as max of 16 random assignments):\n")    

    if (nts == ""):
        break
        
    nts = nts.strip().upper().replace(" ","")

    print(f"Analyzing sequence of length {len(nts)}nt")

    
    dtype = [('position', int), ('score', float)]
    score_functions = [ ("3' MaxEnt", analyze_3ss, 23), 
        ("5' MaxEnt", analyze_5ss, 9), 
        ("5' BRCA2", lambda seq : analyze_5ss_krainer(seq).brca2_9nt, 9), 
        ("5' IKBKAP", lambda seq : analyze_5ss_krainer(seq).ikbkap_9nt, 9), 
        ("5' SMN1", lambda seq : analyze_5ss_krainer(seq).smn1_9nt, 9)]
            
    for (gene, func, site_len) in score_functions:
        scores = [ (i,analyze_with_n(nts[i:i+site_len],func)) for i in range(len(nts)-site_len+1)]
        scores_np = np.array(scores, dtype=dtype)
        scores_sorted = np.flip(np.sort(scores_np,axis=0,order='score'), axis=0)
        
        print(f"Top {NUM_TO_PRINT} splice sites (" + gene + "):")
        for i in range(min(NUM_TO_PRINT,len(scores_sorted))):
            (pos, score) = scores_sorted[i]
            print("%4d" % pos, nts[pos:pos+site_len], "%5.2f" % score)
                    
